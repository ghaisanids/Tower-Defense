using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Data 
{
    public static float coin = 300;
    public static bool isGameOver = false;
    public static bool isComplete = false;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
